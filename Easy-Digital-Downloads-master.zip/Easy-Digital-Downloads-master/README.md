# Easy-Digital-Downloads
This plugin belongs to Qartpay  payment gateway.

Qartpay Digital Downloads

Introduction

Copy the bartipay-ed folder into your installation's wp-content/plugin folder
Activate the plugin through the 'Plugins' menu in WordPress Administration.
Configuration
Login to the admin panel. Browse through till Downloads->Settings->Payment Gateways tab.
Scroll down to "Login and Pay with Qartpay Settings"
Fill in the necessary details for Merchant Pay Id, Merchant Salt Key, Select Mode, Website Name and Industry Type.


Qartpay Payment gateway URL Details

Qartpay Gateway Settings	

	Live API Key	=>  19xxxxxxxxxxxx0
	Test API Key	=>  19xxxxxxxxxxxx0
	 
	Salt Key	    =>  2xxxxxxxxxxxx1

	Merchant Name   =>  Demo Name

	Test Request URL                 => https://dashboard.qartpay.com/crm/jsp/paymentPage.jsp
	Test Response Url                => https://dashboard.qartpay.com/crm/jsp/response.jsp

	Production Request URL           => https://dashboard.qartpay.com/crm/jsp/paymentPage.jsp
	Production Response  Url         => https://dashboard.qartpay.com/crm/jsp/response.jsp
